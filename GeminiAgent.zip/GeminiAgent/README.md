# Gemini Agent (Android 15–17)
1. Google Cloud Console → OAuth-Client "Android" (Paketname `de.simeon.geminiagent`, SHA-1 deines Debug-Keystores), Consent Screen mit Scope `generative-language.retriever`, dich als Testnutzer eintragen.
2. In Android Studio öffnen, Gradle-Sync, auf Gerät starten.
3. Modell-ID im Feld "Modell" setzen.
