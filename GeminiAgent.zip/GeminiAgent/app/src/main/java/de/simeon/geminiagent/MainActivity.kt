package de.simeon.geminiagent

import android.app.Activity
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.IntentSenderRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.text.selection.SelectionContainer
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.unit.dp
import com.google.android.gms.auth.api.identity.AuthorizationRequest
import com.google.android.gms.auth.api.identity.AuthorizationResult
import com.google.android.gms.auth.api.identity.Identity
import com.google.android.gms.common.api.Scope
import kotlinx.coroutines.launch
import org.json.JSONArray
import org.json.JSONObject

// Scope für die Gemini API per OAuth. Falls 403: "https://www.googleapis.com/auth/cloud-platform" testen.
private const val SCOPE = "https://www.googleapis.com/auth/generative-language.retriever"

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { MaterialTheme(colorScheme = darkColorScheme()) { Surface(Modifier.fillMaxSize()) { App() } } }
    }
}

@Composable
fun App() {
    val ctx = androidx.compose.ui.platform.LocalContext.current
    val scope = rememberCoroutineScope()
    var token by remember { mutableStateOf<String?>(null) }
    var status by remember { mutableStateOf("") }
    var model by remember { mutableStateOf("gemini-flash-latest") } // hier deine Modell-ID eintragen
    var thinking by remember { mutableStateOf("high") }
    val msgs = remember { mutableStateListOf<Msg>() }
    var input by remember { mutableStateOf("") }
    var busy by remember { mutableStateOf(false) }
    val list = rememberLazyListState()
    val contents = remember { JSONArray() }
    val workspace = remember { java.io.File(ctx.filesDir, "workspace") }

    fun handle(r: AuthorizationResult) { token = r.accessToken; status = if (token == null) "Kein Token" else "" }

    val consent = rememberLauncherForActivityResult(ActivityResultContracts.StartIntentSenderForResult()) { res ->
        if (res.resultCode == Activity.RESULT_OK && res.data != null)
            handle(Identity.getAuthorizationClient(ctx).getAuthorizationResultFromIntent(res.data!!))
        else status = "Login abgebrochen"
    }

    fun signIn() {
        val req = AuthorizationRequest.builder().setRequestedScopes(listOf(Scope(SCOPE))).build()
        Identity.getAuthorizationClient(ctx).authorize(req)
            .addOnSuccessListener { r ->
                val pi = r.pendingIntent
                if (r.hasResolution() && pi != null) consent.launch(IntentSenderRequest.Builder(pi.intentSender).build())
                else handle(r)
            }
            .addOnFailureListener { status = "Login-Fehler: ${it.message}" }
    }

    fun send() {
        val t = token ?: return
        val text = input.trim().ifEmpty { return }
        input = ""; msgs += Msg("user", text); busy = true
        contents.put(JSONObject().put("role", "user").put("parts", JSONArray().put(JSONObject().put("text", text))))
        scope.launch {
            val answer = runCatching {
                runAgent(t, model, thinking, contents, workspace) { msgs += Msg("tool", it) }
            }.getOrElse { "Fehler: ${it.message}" }
            msgs += Msg("model", answer); busy = false
            list.animateScrollToItem(msgs.lastIndex)
        }
    }

    Column(Modifier.fillMaxSize().systemBarsPadding().imePadding().padding(12.dp)) {
        if (token == null) {
            Column(Modifier.fillMaxSize(), Arrangement.Center, Alignment.CenterHorizontally) {
                Text("Gemini Agent", style = MaterialTheme.typography.headlineMedium)
                Spacer(Modifier.height(16.dp))
                Button(onClick = ::signIn) { Text("Mit Google anmelden") }
                if (status.isNotEmpty()) Text(status, color = Color(0xFFFF6B6B))
            }
        } else {
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedTextField(model, { model = it }, Modifier.weight(1f), label = { Text("Modell") }, singleLine = true)
                OutlinedTextField(thinking, { thinking = it }, Modifier.width(100.dp), label = { Text("Think") }, singleLine = true)
            }
            LazyColumn(Modifier.weight(1f).padding(vertical = 8.dp), state = list, verticalArrangement = Arrangement.spacedBy(8.dp)) {
                items(msgs) { m ->
                    Card(colors = CardDefaults.cardColors(
                        when (m.role) { "user" -> MaterialTheme.colorScheme.primaryContainer; "tool" -> MaterialTheme.colorScheme.tertiaryContainer; else -> MaterialTheme.colorScheme.surfaceVariant })) {
                        SelectionContainer {
                            Text(m.text, Modifier.padding(10.dp),
                                fontFamily = if (m.role == "model") FontFamily.Monospace else FontFamily.Default)
                        }
                    }
                }
            }
            if (busy) LinearProgressIndicator(Modifier.fillMaxWidth())
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedTextField(input, { input = it }, Modifier.weight(1f), placeholder = { Text("Aufgabe…") })
                Button(onClick = ::send, enabled = !busy) { Text("Senden") }
            }
        }
    }
}
