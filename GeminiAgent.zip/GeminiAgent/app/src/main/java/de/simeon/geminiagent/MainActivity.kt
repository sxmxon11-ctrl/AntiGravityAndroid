@file:OptIn(ExperimentalMaterial3Api::class)

package de.simeon.geminiagent

import android.app.Activity
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.IntentSenderRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.selection.SelectionContainer
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.Send
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Build
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.SpanStyle
import androidx.compose.ui.text.buildAnnotatedString
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.withStyle
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.google.android.gms.auth.api.identity.AuthorizationRequest
import com.google.android.gms.auth.api.identity.AuthorizationResult
import com.google.android.gms.auth.api.identity.Identity
import com.google.android.gms.common.api.Scope
import kotlinx.coroutines.Job
import kotlinx.coroutines.launch
import org.json.JSONArray
import org.json.JSONObject

// Scope für die Gemini API per OAuth. Falls 403: "https://www.googleapis.com/auth/cloud-platform" testen.
private const val SCOPE = "https://www.googleapis.com/auth/generative-language.retriever"

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            val ctx = LocalContext.current
            MaterialTheme(colorScheme = if (isSystemInDarkTheme()) dynamicDarkColorScheme(ctx) else dynamicLightColorScheme(ctx)) { App() }
        }
    }
}

private sealed interface Block {
    data class Text(val t: String) : Block
    data class Code(val lang: String, val code: String) : Block
}

private fun parse(md: String): List<Block> {
    val out = mutableListOf<Block>()
    md.split("```").forEachIndexed { i, p ->
        if (i % 2 == 0) { if (p.isNotBlank()) out += Block.Text(p.trim()) }
        else {
            val nl = p.indexOf('\n')
            out += Block.Code(if (nl >= 0) p.substring(0, nl).trim() else "", (if (nl >= 0) p.substring(nl + 1) else p).trimEnd())
        }
    }
    return out
}

private fun inline(s: String, codeBg: Color) = buildAnnotatedString {
    var i = 0
    while (i < s.length) {
        val bold = if (s.startsWith("**", i)) s.indexOf("**", i + 2) else -1
        val code = if (s[i] == '`') s.indexOf('`', i + 1) else -1
        when {
            bold > 0 -> { withStyle(SpanStyle(fontWeight = FontWeight.Bold)) { append(s.substring(i + 2, bold)) }; i = bold + 2 }
            code > 0 -> { withStyle(SpanStyle(fontFamily = FontFamily.Monospace, background = codeBg)) { append(s.substring(i + 1, code)) }; i = code + 1 }
            else -> { append(s[i]); i++ }
        }
    }
}

@Composable
private fun CodeBlock(b: Block.Code) {
    val clip = LocalClipboardManager.current
    Surface(shape = RoundedCornerShape(16.dp), color = MaterialTheme.colorScheme.surfaceContainerHigh) {
        Column {
            Row(Modifier.fillMaxWidth().padding(start = 16.dp, end = 4.dp), verticalAlignment = Alignment.CenterVertically) {
                Text(b.lang.ifBlank { "code" }, Modifier.weight(1f), style = MaterialTheme.typography.labelMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant)
                TextButton(onClick = { clip.setText(AnnotatedString(b.code)) }) { Text("Kopieren") }
            }
            SelectionContainer {
                Text(b.code, Modifier.horizontalScroll(rememberScrollState()).padding(start = 16.dp, end = 16.dp, bottom = 16.dp),
                    fontFamily = FontFamily.Monospace, fontSize = 13.sp)
            }
        }
    }
}

@Composable
private fun MessageItem(m: Msg) {
    val cs = MaterialTheme.colorScheme
    when (m.role) {
        "user" -> Box(Modifier.fillMaxWidth(), contentAlignment = Alignment.CenterEnd) {
            Surface(color = cs.primaryContainer, shape = RoundedCornerShape(20.dp, 20.dp, 4.dp, 20.dp), modifier = Modifier.widthIn(max = 320.dp)) {
                SelectionContainer { Text(m.text, Modifier.padding(horizontal = 16.dp, vertical = 10.dp), color = cs.onPrimaryContainer) }
            }
        }
        "tool" -> Surface(shape = RoundedCornerShape(50), color = cs.secondaryContainer) {
            Row(Modifier.padding(horizontal = 12.dp, vertical = 6.dp), verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Default.Build, null, Modifier.size(16.dp), tint = cs.onSecondaryContainer)
                Spacer(Modifier.width(8.dp))
                Text(m.text.removePrefix("🔧 "), style = MaterialTheme.typography.labelLarge, color = cs.onSecondaryContainer)
            }
        }
        else -> Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
            parse(m.text).forEach { b ->
                when (b) {
                    is Block.Text -> SelectionContainer { Text(inline(b.t, cs.surfaceContainerHigh), style = MaterialTheme.typography.bodyLarge) }
                    is Block.Code -> CodeBlock(b)
                }
            }
        }
    }
}

@Composable
fun App() {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    var token by remember { mutableStateOf<String?>(null) }
    var status by remember { mutableStateOf("") }
    var model by remember { mutableStateOf("gemini-flash-latest") } // hier deine Modell-ID eintragen
    var thinking by remember { mutableStateOf("low") }
    var showSettings by remember { mutableStateOf(false) }
    val msgs = remember { mutableStateListOf<Msg>() }
    var input by remember { mutableStateOf("") }
    var busy by remember { mutableStateOf(false) }
    val list = rememberLazyListState()
    val contents = remember { JSONArray() }
    val gen = remember { intArrayOf(0, 0) } // [0]=Generation, [1]=Länge von contents vor dem Senden
    var job by remember { mutableStateOf<Job?>(null) }
    val workspace = remember { java.io.File(ctx.filesDir, "workspace") }

    LaunchedEffect(msgs.size, msgs.lastOrNull()?.text?.length) { if (msgs.isNotEmpty()) list.scrollToItem(msgs.lastIndex) }

    fun handle(r: AuthorizationResult) { token = r.accessToken; status = if (token == null) "Kein Token erhalten" else "" }

    val consent = rememberLauncherForActivityResult(ActivityResultContracts.StartIntentSenderForResult()) { res ->
        if (res.resultCode == Activity.RESULT_OK && res.data != null)
            handle(Identity.getAuthorizationClient(ctx).getAuthorizationResultFromIntent(res.data!!))
        else status = "Anmeldung abgebrochen"
    }

    fun signIn() {
        val req = AuthorizationRequest.builder().setRequestedScopes(listOf(Scope(SCOPE))).build()
        Identity.getAuthorizationClient(ctx).authorize(req)
            .addOnSuccessListener { r ->
                val pi = r.pendingIntent
                if (r.hasResolution() && pi != null) consent.launch(IntentSenderRequest.Builder(pi.intentSender).build())
                else handle(r)
            }
            .addOnFailureListener { status = "Anmeldefehler: ${it.message}" }
    }

    fun cancel() {
        gen[0]++
        currentCall?.cancel(); job?.cancel(); busy = false
        while (contents.length() > gen[1]) contents.remove(contents.length() - 1)
    }

    fun send() {
        val t = token ?: return
        val text = input.trim().ifEmpty { return }
        input = ""; msgs += Msg("user", text); busy = true
        val my = ++gen[0]
        gen[1] = contents.length()
        contents.put(JSONObject().put("role", "user").put("parts", JSONArray().put(JSONObject().put("text", text))))
        job = scope.launch {
            var live = -1
            val answer = runCatching {
                runAgent(t, model, thinking, contents, workspace,
                    onStep = { if (gen[0] == my) { live = -1; msgs += Msg("tool", it) } },
                    onText = { d ->
                        if (gen[0] == my) {
                            if (live < 0) { msgs += Msg("model", d); live = msgs.lastIndex }
                            else msgs[live] = Msg("model", msgs[live].text + d)
                        }
                    })
            }
            if (gen[0] != my) return@launch
            answer.onFailure { msgs += Msg("model", "Fehler: ${it.message}") }
            answer.onSuccess { if (live < 0 && it.isNotBlank()) msgs += Msg("model", it) }
            busy = false
        }
    }

    fun newChat() { cancel(); msgs.clear(); while (contents.length() > 0) contents.remove(0) }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Gemini Agent", fontWeight = FontWeight.Medium) },
                actions = {
                    if (token != null) {
                        IconButton(onClick = ::newChat) { Icon(Icons.Default.Add, "Neuer Chat") }
                        IconButton(onClick = { showSettings = true }) { Icon(Icons.Default.Settings, "Einstellungen") }
                    }
                },
            )
        },
    ) { pad ->
        if (token == null) {
            Column(Modifier.fillMaxSize().padding(pad).padding(32.dp), Arrangement.Center, Alignment.CenterHorizontally) {
                Surface(shape = CircleShape, color = MaterialTheme.colorScheme.primaryContainer, modifier = Modifier.size(96.dp)) {
                    Box(contentAlignment = Alignment.Center) { Text("✦", fontSize = 44.sp, color = MaterialTheme.colorScheme.onPrimaryContainer) }
                }
                Spacer(Modifier.height(24.dp))
                Text("Dein Coding-Agent", style = MaterialTheme.typography.headlineMedium)
                Spacer(Modifier.height(8.dp))
                Text("Melde dich mit Google an und lass Gemini Code schreiben, lesen und ändern.",
                    textAlign = TextAlign.Center, color = MaterialTheme.colorScheme.onSurfaceVariant)
                Spacer(Modifier.height(32.dp))
                Button(onClick = ::signIn, Modifier.fillMaxWidth().height(52.dp)) { Text("Mit Google anmelden") }
                if (status.isNotEmpty()) { Spacer(Modifier.height(12.dp)); Text(status, color = MaterialTheme.colorScheme.error) }
            }
        } else {
            Column(Modifier.fillMaxSize().padding(pad).consumeWindowInsets(pad).imePadding()) {
                if (msgs.isEmpty()) {
                    Column(Modifier.weight(1f).fillMaxWidth().padding(24.dp), Arrangement.Center, Alignment.CenterHorizontally) {
                        Text("Wobei kann ich helfen?", style = MaterialTheme.typography.headlineSmall)
                        Spacer(Modifier.height(16.dp))
                        listOf("Erstelle eine HTML-Seite im Material-You-Design", "Zeig mir die Dateien im Projekt", "Schreibe ein Python-Skript")
                            .forEach { s -> SuggestionChip(onClick = { input = s }, label = { Text(s) }, modifier = Modifier.padding(vertical = 2.dp)) }
                    }
                } else {
                    LazyColumn(Modifier.weight(1f).fillMaxWidth(), state = list,
                        contentPadding = PaddingValues(16.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
                        items(msgs) { MessageItem(it) }
                        if (busy && msgs.lastOrNull()?.role != "model") item {
                            Text("Gemini denkt nach …", color = MaterialTheme.colorScheme.onSurfaceVariant, style = MaterialTheme.typography.bodyMedium)
                        }
                    }
                }
                Row(Modifier.fillMaxWidth().padding(12.dp), verticalAlignment = Alignment.Bottom, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(input, { input = it }, Modifier.weight(1f), placeholder = { Text("Nachricht an Gemini") },
                        shape = RoundedCornerShape(28.dp), maxLines = 5)
                    FilledIconButton(onClick = { if (busy) cancel() else send() }, enabled = busy || input.isNotBlank(), modifier = Modifier.size(56.dp)) {
                        if (busy) Icon(Icons.Default.Close, "Abbrechen")
                        else Icon(Icons.AutoMirrored.Filled.Send, "Senden")
                    }
                }
            }
        }
    }

    if (showSettings) ModalBottomSheet(onDismissRequest = { showSettings = false }) {
        Column(Modifier.padding(horizontal = 24.dp).padding(bottom = 32.dp), verticalArrangement = Arrangement.spacedBy(16.dp)) {
            Text("Einstellungen", style = MaterialTheme.typography.titleLarge)
            OutlinedTextField(model, { model = it }, Modifier.fillMaxWidth(), label = { Text("Modell-ID") }, singleLine = true)
            Text("Denktiefe", style = MaterialTheme.typography.labelLarge)
            Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                listOf("", "minimal", "low", "medium", "high").forEach {
                    FilterChip(selected = thinking == it, onClick = { thinking = it }, label = { Text(it.ifEmpty { "Standard" }) })
                }
            }
            OutlinedButton(onClick = { token = null; showSettings = false; newChat() }, Modifier.fillMaxWidth()) { Text("Abmelden") }
        }
    }
}
