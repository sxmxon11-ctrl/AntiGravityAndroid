package de.simeon.geminiagent

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.RequestBody.Companion.toRequestBody

data class Msg(val role: String, val text: String) // role: "user" | "model" | "tool"

const val SYSTEM_PROMPT = "Du bist ein Coding-Agent mit Zugriff auf einen Projektordner. Nutze list_files, " +
    "read_file und write_file, um Code zu lesen und zu ändern. Antworte knapp, finde Root Causes, erkläre nur das Nötige."

private fun fn(name: String, desc: String, props: JSONObject, req: List<String>) = JSONObject()
    .put("name", name).put("description", desc)
    .put("parameters", JSONObject().put("type", "object").put("properties", props).put("required", JSONArray(req)))

private fun str(d: String) = JSONObject().put("type", "string").put("description", d)

private val TOOLS = JSONArray().put(JSONObject().put("functionDeclarations", JSONArray()
    .put(fn("list_files", "Listet alle Dateien im Projektordner (rekursiv).", JSONObject(), emptyList()))
    .put(fn("read_file", "Liest eine Datei.", JSONObject().put("path", str("Relativer Pfad")), listOf("path")))
    .put(fn("write_file", "Schreibt/überschreibt eine Datei.",
        JSONObject().put("path", str("Relativer Pfad")).put("content", str("Kompletter Inhalt")), listOf("path", "content")))))

private fun safe(root: File, p: String): File {
    val f = File(root, p).canonicalFile
    require(f.path.startsWith(root.canonicalPath)) { "Pfad außerhalb des Projekts" }
    return f
}

private fun runTool(root: File, name: String, a: JSONObject): String = try {
    when (name) {
        "list_files" -> root.walkTopDown().filter { it.isFile }.joinToString("\n") { it.relativeTo(root).path }.ifEmpty { "(leer)" }
        "read_file" -> safe(root, a.getString("path")).readText()
        "write_file" -> safe(root, a.getString("path")).let { it.parentFile?.mkdirs(); it.writeText(a.getString("content")); "OK" }
        else -> "Unbekanntes Tool"
    }
} catch (e: Exception) { "Fehler: ${e.message}" }

@Volatile var currentCall: okhttp3.Call? = null

private val http = okhttp3.OkHttpClient.Builder()
    .protocols(listOf(okhttp3.Protocol.HTTP_1_1))
    .connectTimeout(15, java.util.concurrent.TimeUnit.SECONDS)
    .readTimeout(180, java.util.concurrent.TimeUnit.SECONDS)
    .writeTimeout(60, java.util.concurrent.TimeUnit.SECONDS)
    .retryOnConnectionFailure(true)
    .build()

/** Streamt die Antwort (SSE), ruft onText pro Textstück auf und liefert die gesammelten Parts zurück. */
private fun stream(token: String, model: String, body: JSONObject, onText: (String) -> Unit): JSONArray {
    val req = okhttp3.Request.Builder()
        .url("https://generativelanguage.googleapis.com/v1beta/models/$model:streamGenerateContent?alt=sse")
        .header("Authorization", "Bearer $token")
        .post(body.toString().toRequestBody("application/json".toMediaType()))
        .build()
    var last: Exception? = null
    repeat(3) {
        val parts = JSONArray()
        var started = false
        val call = http.newCall(req)
        currentCall = call
        try {
            call.execute().use { r ->
                if (!r.isSuccessful) error("HTTP ${r.code}: ${r.body?.string().orEmpty()}")
                val src = r.body!!.source()
                while (true) {
                    val line = src.readUtf8Line() ?: break
                    if (!line.startsWith("data:")) continue
                    started = true
                    val chunk = JSONObject(line.removePrefix("data:").trim())
                    val ps = chunk.optJSONArray("candidates")?.optJSONObject(0)
                        ?.optJSONObject("content")?.optJSONArray("parts") ?: continue
                    for (i in 0 until ps.length()) {
                        val part = ps.getJSONObject(i)
                        val plain = part.has("text") && !part.optBoolean("thought") && !part.has("thoughtSignature")
                        if (part.has("text") && !part.optBoolean("thought")) onText(part.getString("text"))
                        val prev = if (parts.length() > 0) parts.getJSONObject(parts.length() - 1) else null
                        val prevPlain = prev != null && prev.has("text") && !prev.optBoolean("thought") && !prev.has("thoughtSignature")
                        if (plain && prevPlain) prev!!.put("text", prev.getString("text") + part.getString("text"))
                        else parts.put(part)
                    }
                }
            }
            return parts
        } catch (e: java.io.IOException) {
            if (call.isCanceled()) throw kotlinx.coroutines.CancellationException("abgebrochen")
            last = e
            if (started) error("Verbindung unterbrochen: ${e.message}")
            Thread.sleep(1500)
        }
    }
    error("Netzwerk: ${last?.javaClass?.simpleName}: ${last?.message}")
}

/** Agent-Loop: streamt Gemini, führt Tool-Calls aus, bis eine Textantwort kommt. */
suspend fun runAgent(
    token: String, model: String, thinking: String,
    contents: JSONArray, workspace: File,
    onStep: (String) -> Unit, onText: (String) -> Unit,
): String = withContext(Dispatchers.IO) {
    workspace.mkdirs()
    repeat(15) {
        val gen = JSONObject()
        if (thinking.isNotBlank()) gen.put("thinkingConfig", JSONObject().put("thinkingLevel", thinking.trim()))
        val body = JSONObject()
            .put("systemInstruction", JSONObject().put("parts", JSONArray().put(JSONObject().put("text", SYSTEM_PROMPT))))
            .put("contents", contents).put("tools", TOOLS).put("generationConfig", gen)
        val parts = stream(token, model, body, onText)
        contents.put(JSONObject().put("role", "model").put("parts", parts)) // unverändert (Thought-Signatures)
        val calls = (0 until parts.length()).map { parts.getJSONObject(it) }.filter { it.has("functionCall") }
        if (calls.isEmpty())
            return@withContext (0 until parts.length()).joinToString("") { parts.getJSONObject(it).optString("text") }
        val responses = JSONArray()
        for (p in calls) {
            val call = p.getJSONObject("functionCall")
            val name = call.getString("name")
            val args = call.optJSONObject("args") ?: JSONObject()
            onStep("🔧 $name ${args.optString("path")}")
            responses.put(JSONObject().put("functionResponse", JSONObject().put("name", name)
                .put("response", JSONObject().put("result", runTool(workspace, name, args)))))
        }
        contents.put(JSONObject().put("role", "user").put("parts", responses))
    }
    "Abbruch: zu viele Tool-Schritte."
}
