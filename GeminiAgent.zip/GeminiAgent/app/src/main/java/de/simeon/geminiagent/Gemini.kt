package de.simeon.geminiagent

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.net.HttpURLConnection
import java.net.URL

data class Msg(val role: String, val text: String) // role: "user" | "model" | "tool"

const val SYSTEM_PROMPT = "Du bist ein Coding-Agent mit Zugriff auf einen Projektordner. Nutze list_files, " +
    "read_file und write_file, um Code zu lesen und zu ändern. Antworte knapp, finde Root Causes, erkläre nur das Nötige."

private fun fn(name: String, desc: String, props: JSONObject, req: List<String>) = JSONObject()
    .put("name", name).put("description", desc)
    .put("parameters", JSONObject().put("type", "object").put("properties", props).put("required", JSONArray(req)))

private fun str(d: String) = JSONObject().put("type", "string").put("description", d)

private val TOOLS = JSONArray().put(JSONObject().put("functionDeclarations", JSONArray()
    .put(fn("list_files", "Listet alle Dateien im Projektordner (rekursiv).", JSONObject(), emptyList()))
    .put(fn("read_file", "Liest eine Datei.", JSONObject().put("path", str("Relativer Pfad")), listOf("path")))
    .put(fn("write_file", "Schreibt/überschreibt eine Datei.",
        JSONObject().put("path", str("Relativer Pfad")).put("content", str("Kompletter Inhalt")), listOf("path", "content")))))

private fun safe(root: File, p: String): File {
    val f = File(root, p).canonicalFile
    require(f.path.startsWith(root.canonicalPath)) { "Pfad außerhalb des Projekts" }
    return f
}

private fun runTool(root: File, name: String, a: JSONObject): String = try {
    when (name) {
        "list_files" -> root.walkTopDown().filter { it.isFile }.joinToString("\n") { it.relativeTo(root).path }.ifEmpty { "(leer)" }
        "read_file" -> safe(root, a.getString("path")).readText()
        "write_file" -> safe(root, a.getString("path")).let { it.parentFile?.mkdirs(); it.writeText(a.getString("content")); "OK" }
        else -> "Unbekanntes Tool"
    }
} catch (e: Exception) { "Fehler: ${e.message}" }

private fun post(token: String, model: String, body: JSONObject): JSONObject {
    val c = URL("https://generativelanguage.googleapis.com/v1beta/models/$model:generateContent")
        .openConnection() as HttpURLConnection
    c.requestMethod = "POST"
    c.setRequestProperty("Authorization", "Bearer $token")
    c.setRequestProperty("Content-Type", "application/json")
    c.doOutput = true
    c.outputStream.use { it.write(body.toString().toByteArray()) }
    val ok = c.responseCode in 200..299
    val raw = (if (ok) c.inputStream else c.errorStream).bufferedReader().readText()
    if (!ok) error("HTTP ${c.responseCode}: $raw")
    return JSONObject(raw)
}

/** Agent-Loop: ruft Gemini, führt Tool-Calls aus, bis eine Textantwort kommt. `contents` bleibt über Turns erhalten. */
suspend fun runAgent(
    token: String, model: String, thinking: String,
    contents: JSONArray, workspace: File, onStep: (String) -> Unit,
): String = withContext(Dispatchers.IO) {
    workspace.mkdirs()
    repeat(15) {
        val body = JSONObject()
            .put("systemInstruction", JSONObject().put("parts", JSONArray().put(JSONObject().put("text", SYSTEM_PROMPT))))
            .put("contents", contents).put("tools", TOOLS)
            .put("generationConfig", JSONObject().put("thinkingConfig", JSONObject().put("thinkingLevel", thinking)))
        val content = post(token, model, body).getJSONArray("candidates").getJSONObject(0).getJSONObject("content")
        contents.put(content) // unverändert zurückgeben (enthält Thought-Signatures)
        val parts = content.optJSONArray("parts") ?: JSONArray()
        val calls = (0 until parts.length()).map { parts.getJSONObject(it) }.filter { it.has("functionCall") }
        if (calls.isEmpty())
            return@withContext (0 until parts.length()).joinToString("") { parts.getJSONObject(it).optString("text") }
        val responses = JSONArray()
        for (p in calls) {
            val call = p.getJSONObject("functionCall")
            val name = call.getString("name")
            val args = call.optJSONObject("args") ?: JSONObject()
            onStep("🔧 $name ${args.optString("path")}")
            responses.put(JSONObject().put("functionResponse", JSONObject().put("name", name)
                .put("response", JSONObject().put("result", runTool(workspace, name, args)))))
        }
        contents.put(JSONObject().put("role", "user").put("parts", responses))
    }
    "Abbruch: zu viele Tool-Schritte."
}
